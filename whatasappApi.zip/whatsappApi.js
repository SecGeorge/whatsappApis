const wppconnect = require('@wppconnect-team/wppconnect');
const express = require('express');
const app = express();
const http = require('http'); // Cambiado a HTTP
const WebSocket = require('ws');
const cors = require('cors');
const fs = require('fs');
const multer = require('multer');
const path = require('path');
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
// Configuración de Multer para manejo de archivos temporales
const upload = multer({
    dest: path.join(__dirname, 'uploads'), // Carpeta temporal para archivos subidos
});
// Crear el servidor HTTP para Express
const server = http.createServer(app); // Cambiado a HTTP

// Configuración del servidor WebSocket
const ws = new WebSocket.Server({ server });

// Variable global para almacenar la instancia del cliente
let clientInstance = null;

// Función para enviar datos a los clientes conectados
const broadcast = (data) => {
    ws.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify(data));
        }
    });
};

// Manejar cuando un cliente se conecta
ws.on('connection', (wsClient) => {
    console.log('Un nuevo cliente se ha conectado');
    wsClient.send(JSON.stringify({ message: 'Conectado al servidor' }));

    wsClient.on('message', (message) => {
        console.log('Mensaje recibido del cliente:', message);
    });

    wsClient.on('close', () => {
        console.log('Un cliente se ha desconectado');
    });

    wsClient.on('error', (error) => {
        console.error('Error en WebSocket:', error);
    });
});

// Inicializar WPPConnect solo si no hay una sesión activa
const initializeWPPConnect = () => {
    if (clientInstance !== null) {
        console.log('Ya hay una sesión activa, esperando a que se cierre...');
        return;
    }

    wppconnect.create({
        session: 'whatsapp-session',
        headless: true,
        useChrome: true,
        autoClose: false,
        disableSpins: true,
        catchQR: (base64Qr, asciiQR) => {
            console.log(asciiQR); // Optional to log the QR in the terminal

            // Extraer los datos del QR en base64
            var matches = base64Qr.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/),
                response = {};

            if (matches.length !== 3) {
                return new Error('Invalid input string');
            }

            response.type = matches[1];
            response.data = new Buffer.from(matches[2], 'base64');

            var imageBuffer = response;

            // Guardar el QR en un archivo 'out.png'
            fs.writeFile('out.png', imageBuffer['data'], 'binary', function (err) {
                if (err != null) {
                    console.log(err);
                }
            });

            // Enviar el QR code a todos los clientes conectados
            broadcast({ qr: base64Qr });
            console.log('QR enviado a los clientes');
        },
        logQR: false,
    })
    .then(client => {
        clientInstance = client; // Guardar la instancia del cliente

        console.log('WPPConnect iniciado correctamente');

        // Escuchar cuando cambia el estado del cliente
        client.onStateChange(state => {
            console.log('Estado de la sesión de WhatsApp:', state);

            if (state === 'CONNECTED') {
                console.log('Cliente conectado exitosamente');
                broadcast({ message: 'QR_SCANNED' });
            }
        });

        // Escuchar la desconexión del cliente para limpiar la instancia
    
    })
    .catch(error => {
        console.error('Error inicializando WPPConnect:', error);
    });
};

// Llamar a la función para inicializar WPPConnect
initializeWPPConnect();

// Enviar mensaje de texto
app.post('/send-message', async (req, res) => {
    const { number, message } = req.body;

    console.log('Número Completo:', number);  // Verifica el número recibido
    console.log('Mensaje:', message);         // Verifica el mensaje recibido

    try {
        await clientInstance.sendText(`${number}@c.us`, message)

        .then((result) => {
        console.log('Resultado al enviar: ', result);
        res.send({ status: 'Mensaje enviado', response: result }); 
        })
        .catch((erro) => {
        console.error('Error al enviar: ', erro);
        res.status(500).send({ status: 'Error', error: erro });
        
            console.log('Número Completo:', number);  // Verifica el número recibido
            console.log('Mensaje:', message);  
        });
    } catch (error) {
    console.error('Error al enviar mensaje:', error);
    res.status(500).send({ status: 'Error', error });
    }
});

// Ruta para maneja

app.post('/send-image', upload.single('image'), async (req, res) => {
    const { number, caption } = req.body;
  
    if (!req.file) {
      return res.status(400).send({ status: 'Error', error: 'No se recibió la imagen en la solicitud.' });
    }
  
    const imagePath = req.file.path;  // Ruta del archivo subido
  
    try {
      // Enviar la imagen utilizando wppconnect
      const response = await clientInstance.sendImage(
        `${number}@c.us`,             // Número con código de país
        imagePath,                     // Ruta de la imagen
        req.file.originalname || 'imagen.jpg',  // Nombre del archivo
        caption || 'Aquí tienes tu imagen.'     // Texto opcional
      );
  
      console.log('Imagen enviada correctamente:', response);
      res.send({ status: 'Imagen enviada', response });
    } catch (error) {
      console.error('Error al enviar imagen:', error);
      res.status(500).send({ status: 'Error', error: error.message });
      console.log(imagePath)
      console.log('Mensaje:', number);  
    } finally {
      fs.unlinkSync(imagePath);  // Eliminar la imagen temporal después de enviarla
    }
  });

// Inicia el servidor
const port = 8082;
server.listen(port, () => {
    console.log(`API de WhatsApp escuchando en http://localhost:${server.address().port}`);
});
